<?php
    require_once $_SERVER['DOCUMENT_ROOT'].'/includes/lib.php';
    recommendHotels(1);
?>