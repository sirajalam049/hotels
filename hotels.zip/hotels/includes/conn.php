<?php

    function con(){
        $u = '';
        $p = '';
        $d = '';

        $GLOBALS['con'] = new mysqli('localhost', $u, $p,$d )
            or die('Connection Failed. '.$con->error);
    }

?>